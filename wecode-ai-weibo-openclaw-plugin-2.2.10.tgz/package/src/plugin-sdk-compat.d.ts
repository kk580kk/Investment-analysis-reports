export type MediaItem = {
    path: string;
    contentType?: string | null;
};
export type AgentMediaPayload = {
    MediaPath?: string;
    MediaPaths?: string[];
    MediaType?: string;
    MediaTypes?: string[];
    MediaUrl?: string;
    MediaUrls?: string[];
};
export declare function buildAgentMediaPayloadCompat(mediaList: MediaItem[]): AgentMediaPayload;
export declare function waitUntilAbortCompat(abortSignal?: AbortSignal): Promise<void>;
//# sourceMappingURL=plugin-sdk-compat.d.ts.map