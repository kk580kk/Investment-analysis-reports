import type { PluginRuntime } from "openclaw/plugin-sdk/core";
export declare function setWeiboRuntime(runtime: PluginRuntime): void;
export declare function getWeiboRuntime(): PluginRuntime;
//# sourceMappingURL=runtime.d.ts.map