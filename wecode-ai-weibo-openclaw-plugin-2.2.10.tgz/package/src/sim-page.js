export function getLatestCredentialFromState(state) {
    const credentials = Array.isArray(state.credentials) ? state.credentials : [];
    if (credentials.length === 0) {
        return null;
    }
    const sorted = [...credentials].sort((a, b) => {
        const aTs = typeof a.createdAt === "number" ? a.createdAt : 0;
        const bTs = typeof b.createdAt === "number" ? b.createdAt : 0;
        return bTs - aTs;
    });
    const first = sorted[0];
    const appId = String(first?.appId ?? "").trim();
    const appSecret = String(first?.appSecret ?? "").trim();
    if (!appId || !appSecret) {
        return null;
    }
    return { appId, appSecret };
}
export function getSimPageEndpoints({ pageOrigin, wsPort, }) {
    const origin = new URL(pageOrigin);
    const wsProtocol = origin.protocol === "https:" ? "wss:" : "ws:";
    const tokenUrl = new URL("/open/auth/ws_token", origin).toString();
    const wsUrl = `${wsProtocol}//${origin.hostname}:${wsPort}/ws/stream`;
    return {
        tokenUrl,
        wsUrl,
    };
}
export function getSimUiUrl({ host, httpPort, }) {
    return `http://${host}:${httpPort}/`;
}
export function buildSimInputItems(params) {
    const content = [];
    const text = params.text.trim();
    if (text) {
        content.push({
            type: "input_text",
            text,
        });
    }
    for (const attachment of params.attachments ?? []) {
        content.push({
            type: attachment.kind === "image" ? "input_image" : "input_file",
            filename: attachment.filename,
            source: {
                type: "base64",
                media_type: attachment.mimeType,
                data: attachment.dataBase64,
            },
        });
    }
    if (content.length === 0) {
        return undefined;
    }
    return [
        {
            type: "message",
            role: "user",
            content,
        },
    ];
}
export function buildSimInboundPayload(params) {
    return {
        messageId: params.messageId,
        fromUserId: params.fromUserId,
        text: params.text,
        timestamp: params.timestamp,
        ...(params.input?.length ? { input: params.input } : {}),
    };
}
//# sourceMappingURL=sim-page.js.map