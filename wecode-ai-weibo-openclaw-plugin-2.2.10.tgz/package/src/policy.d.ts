export declare function resolveWeiboAllowlistMatch({ userId, allowFrom, }: {
    userId: string;
    allowFrom: string[];
}): boolean;
//# sourceMappingURL=policy.d.ts.map