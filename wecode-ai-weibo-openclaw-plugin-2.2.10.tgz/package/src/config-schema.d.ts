import { z } from "zod";
export { z };
/**
 * Weibo tools configuration.
 * Controls which tool categories are enabled.
 */
export declare const WeiboToolsConfigSchema: z.ZodOptional<z.ZodObject<{
    search: z.ZodOptional<z.ZodBoolean>;
    myWeibo: z.ZodOptional<z.ZodBoolean>;
    hotSearch: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>>;
export declare const WeiboAccountConfigSchema: z.ZodObject<{
    dmPolicy: z.ZodOptional<z.ZodDefault<z.ZodEnum<{
        open: "open";
        pairing: "pairing";
    }>>>;
    allowFrom: z.ZodOptional<z.ZodArray<z.ZodString>>;
    textChunkLimit: z.ZodOptional<z.ZodNumber>;
    chunkMode: z.ZodDefault<z.ZodEnum<{
        length: "length";
        newline: "newline";
        raw: "raw";
    }>>;
    blockStreaming: z.ZodDefault<z.ZodBoolean>;
    tools: z.ZodOptional<z.ZodObject<{
        search: z.ZodOptional<z.ZodBoolean>;
        myWeibo: z.ZodOptional<z.ZodBoolean>;
        hotSearch: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    enabled: z.ZodOptional<z.ZodBoolean>;
    name: z.ZodOptional<z.ZodString>;
    appId: z.ZodOptional<z.ZodString>;
    appSecret: z.ZodOptional<z.ZodString>;
    wsEndpoint: z.ZodDefault<z.ZodString>;
    tokenEndpoint: z.ZodDefault<z.ZodString>;
}, z.core.$strict>;
export declare const WeiboConfigSchema: z.ZodObject<{
    accounts: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodOptional<z.ZodObject<{
        dmPolicy: z.ZodOptional<z.ZodDefault<z.ZodEnum<{
            open: "open";
            pairing: "pairing";
        }>>>;
        allowFrom: z.ZodOptional<z.ZodArray<z.ZodString>>;
        textChunkLimit: z.ZodOptional<z.ZodNumber>;
        chunkMode: z.ZodDefault<z.ZodEnum<{
            length: "length";
            newline: "newline";
            raw: "raw";
        }>>;
        blockStreaming: z.ZodDefault<z.ZodBoolean>;
        tools: z.ZodOptional<z.ZodObject<{
            search: z.ZodOptional<z.ZodBoolean>;
            myWeibo: z.ZodOptional<z.ZodBoolean>;
            hotSearch: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>>;
        enabled: z.ZodOptional<z.ZodBoolean>;
        name: z.ZodOptional<z.ZodString>;
        appId: z.ZodOptional<z.ZodString>;
        appSecret: z.ZodOptional<z.ZodString>;
        wsEndpoint: z.ZodDefault<z.ZodString>;
        tokenEndpoint: z.ZodDefault<z.ZodString>;
    }, z.core.$strict>>>>;
    dmPolicy: z.ZodOptional<z.ZodDefault<z.ZodEnum<{
        open: "open";
        pairing: "pairing";
    }>>>;
    allowFrom: z.ZodOptional<z.ZodArray<z.ZodString>>;
    textChunkLimit: z.ZodOptional<z.ZodNumber>;
    chunkMode: z.ZodDefault<z.ZodEnum<{
        length: "length";
        newline: "newline";
        raw: "raw";
    }>>;
    blockStreaming: z.ZodDefault<z.ZodBoolean>;
    tools: z.ZodOptional<z.ZodObject<{
        search: z.ZodOptional<z.ZodBoolean>;
        myWeibo: z.ZodOptional<z.ZodBoolean>;
        hotSearch: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    enabled: z.ZodOptional<z.ZodBoolean>;
    appId: z.ZodOptional<z.ZodString>;
    appSecret: z.ZodOptional<z.ZodString>;
    wsEndpoint: z.ZodDefault<z.ZodString>;
    tokenEndpoint: z.ZodDefault<z.ZodString>;
}, z.core.$strict>;
//# sourceMappingURL=config-schema.d.ts.map