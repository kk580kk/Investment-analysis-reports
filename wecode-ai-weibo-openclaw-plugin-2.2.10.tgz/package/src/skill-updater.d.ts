/**
 * Skills 自动更新模块
 *
 * 通过心跳触发检查并更新 skills 文件，支持：
 * - 更新现有 skill 的文件
 * - 新增 skill（远程有、本地没有）
 */
/**
 * 触发 skill 更新检查（如果需要）
 * 由心跳调用，通过时间戳节流控制检查频率
 * 异步执行，不阻塞调用方
 */
export declare function triggerSkillUpdateIfNeeded(): void;
//# sourceMappingURL=skill-updater.d.ts.map