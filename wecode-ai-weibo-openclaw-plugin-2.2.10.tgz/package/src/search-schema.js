import { Type } from "@sinclair/typebox";
export const WeiboSearchSchema = Type.Object({
    query: Type.String({ description: "搜索关键词" }),
});
//# sourceMappingURL=search-schema.js.map