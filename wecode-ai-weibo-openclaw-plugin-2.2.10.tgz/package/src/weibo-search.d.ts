import type { OpenClawPluginApi } from "openclaw/plugin-sdk/core";
/**
 * 微博搜索 API 响应结构
 * API: https://open-im.api.weibo.com/open/wis/search_query
 */
export type WeiboSearchApiResponse = {
    code: number;
    message: string;
    data: {
        analyzing: boolean;
        completed: boolean;
        msg: string;
        msg_format: string;
        msg_json: string;
        noContent: boolean;
        profile_image_url: string;
        reference_num: number;
        refused: boolean;
        scheme: string;
        status: number;
        status_stage: number;
        version: string;
        callTime?: string;
        source?: string;
    };
};
export type WeiboSearchStatusItem = {
    id: string;
    mid: string;
    text: string;
    source: string;
    created_at: string;
    user: {
        id: string;
        screen_name: string;
        profile_image_url: string;
        followers_count: number;
        friends_count: number;
        statuses_count: number;
        verified: boolean;
        verified_type: number;
        description: string;
    };
    reposts_count: number;
    comments_count: number;
    attitudes_count: number;
    pic_urls?: Array<{
        thumbnail_pic: string;
    }>;
    retweeted_status?: WeiboSearchStatusItem;
};
export type WeiboSearchResponse = {
    statuses: WeiboSearchStatusItem[];
    total_number: number;
    previous_cursor: number;
    next_cursor: number;
};
export type WeiboSearchConfig = {
    /** 搜索 API 端点，默认为 open-im.api.weibo.com */
    weiboSearchEndpoint?: string;
    /** App ID，用于获取 token */
    appId?: string;
    /** App Secret，用于获取 token */
    appSecret?: string;
    /** Token 端点，默认为 https://open-im.api.weibo.com/open/auth/ws_token */
    tokenEndpoint?: string;
    /** 是否启用搜索工具，默认为 true */
    enabled?: boolean;
};
export declare function registerWeiboSearchTools(api: OpenClawPluginApi): void;
//# sourceMappingURL=weibo-search.d.ts.map