export type SimLogLevel = "info" | "warn" | "error";
export type SimCredential = {
    appId: string;
    appSecret: string;
    createdAt: number;
};
export type SimTokenInfo = {
    token: string;
    appId: string;
    createdAt: number;
    expireIn: number;
};
export type SimMessageDirection = "inbound" | "outbound";
export type SimMessageRecord = {
    id: string;
    direction: SimMessageDirection;
    appId: string;
    fromUserId?: string;
    toUserId?: string;
    text: string;
    timestamp: number;
    wsType?: string;
    rawText?: string;
    rawPayload?: unknown;
};
export type SimLogRecord = {
    id: string;
    level: SimLogLevel;
    message: string;
    timestamp: number;
    details?: unknown;
};
type SimStoreOptions = {
    maxLogEntries?: number;
    maxMessageEntries?: number;
};
type AppendMessageInput = Omit<SimMessageRecord, "id"> & {
    id?: string;
};
export declare function createSimStore(options?: SimStoreOptions): {
    registerCredentials: (appId: string, appSecret: string, createdAt?: number) => SimCredential;
    issueCredentials: () => SimCredential;
    listCredentials: () => SimCredential[];
    issueToken: (appId: string, appSecret: string, ttlSeconds: number) => SimTokenInfo;
    validateToken: (token: string) => SimTokenInfo | null;
    listTokens: () => SimTokenInfo[];
    appendMessage: (message: AppendMessageInput) => SimMessageRecord;
    listMessages: (limit?: number) => SimMessageRecord[];
    appendLog: (level: SimLogLevel, message: string, details?: unknown) => SimLogRecord;
    listLogs: (limit?: number) => SimLogRecord[];
};
export type SimStore = ReturnType<typeof createSimStore>;
export {};
//# sourceMappingURL=sim-store.d.ts.map