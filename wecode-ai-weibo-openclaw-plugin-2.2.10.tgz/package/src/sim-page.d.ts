import type { WeiboResponseMessageInputItem } from "./types.js";
type SimStateLike = {
    credentials?: Array<{
        appId?: unknown;
        appSecret?: unknown;
        createdAt?: unknown;
    }>;
};
export type LatestCredential = {
    appId: string;
    appSecret: string;
};
export type SimPageEndpoints = {
    tokenUrl: string;
    wsUrl: string;
};
export type SimInboundPayload = {
    messageId: string;
    fromUserId: string;
    text: string;
    timestamp: number;
    input?: WeiboResponseMessageInputItem[];
};
export type SimComposerAttachment = {
    kind: "image" | "file";
    filename: string;
    mimeType: string;
    dataBase64: string;
};
export declare function getLatestCredentialFromState(state: SimStateLike): LatestCredential | null;
export declare function getSimPageEndpoints({ pageOrigin, wsPort, }: {
    pageOrigin: string;
    wsPort: number;
}): SimPageEndpoints;
export declare function getSimUiUrl({ host, httpPort, }: {
    host: string;
    httpPort: number;
}): string;
export declare function buildSimInputItems(params: {
    text: string;
    attachments?: SimComposerAttachment[];
}): WeiboResponseMessageInputItem[] | undefined;
export declare function buildSimInboundPayload(params: {
    messageId: string;
    fromUserId: string;
    text: string;
    timestamp: number;
    input?: WeiboResponseMessageInputItem[];
}): SimInboundPayload;
export {};
//# sourceMappingURL=sim-page.d.ts.map