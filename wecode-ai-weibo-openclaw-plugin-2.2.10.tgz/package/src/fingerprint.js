function normalizePart(value) {
    return String(value ?? "").trim();
}
export function getWeiboConnectionFingerprint(account) {
    return JSON.stringify({
        appId: normalizePart(account.appId),
        appSecret: normalizePart(account.appSecret),
        wsEndpoint: normalizePart(account.wsEndpoint),
        tokenEndpoint: normalizePart(account.tokenEndpoint),
    });
}
export function getWeiboTokenFingerprint(account, tokenEndpoint) {
    return JSON.stringify({
        appId: normalizePart(account.appId),
        appSecret: normalizePart(account.appSecret),
        tokenEndpoint: normalizePart(tokenEndpoint ?? account.tokenEndpoint),
    });
}
//# sourceMappingURL=fingerprint.js.map