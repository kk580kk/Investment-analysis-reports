import { WeiboSearchSchema } from "./search-schema.js";
import { getValidWeiboToken } from "./weibo-token-tool.js";
// ============ Helpers ============
function json(data) {
    return {
        content: [{ type: "text", text: JSON.stringify(data, null, 2) }],
        details: data,
    };
}
function readOptionalNonBlankString(value) {
    if (typeof value === "number" && !Number.isNaN(value)) {
        return String(value);
    }
    if (typeof value !== "string") {
        return undefined;
    }
    const trimmed = value.trim();
    return trimmed ? trimmed : undefined;
}
// ============ Core Functions ============
// 默认搜索端点
const DEFAULT_SEARCH_ENDPOINT = "https://open-im.api.weibo.com/open/wis/search_query";
/**
 * 搜索微博内容
 * 使用 token 认证方式访问
 */
async function searchWeibo(query, token, weiboSearchEndpoint) {
    const endpoint = weiboSearchEndpoint || DEFAULT_SEARCH_ENDPOINT;
    const url = new URL(endpoint);
    url.searchParams.set("query", query);
    url.searchParams.set("token", token);
    const response = await fetch(url.toString(), {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
        },
    });
    if (!response.ok) {
        const errorText = await response.text().catch(() => "");
        throw new Error(`微博搜索失败: ${response.status} ${response.statusText}${errorText ? ` - ${errorText}` : ""}`);
    }
    const result = (await response.json());
    return result;
}
/**
 * 格式化搜索结果
 */
function formatSearchResult(result) {
    if (result.code !== 0) {
        return {
            success: false,
            error: result.message || "搜索失败",
        };
    }
    const data = result.data;
    // 如果没有内容
    if (data.noContent) {
        return {
            success: true,
            completed: data.completed,
            noContent: true,
            callTime: data.callTime,
            source: data.source,
            message: "没有找到相关内容",
        };
    }
    // 如果被拒绝
    if (data.refused) {
        return {
            success: false,
            error: "搜索请求被拒绝",
        };
    }
    return {
        success: true,
        completed: data.completed,
        analyzing: data.analyzing,
        content: data.msg,
        contentFormat: data.msg_format,
        referenceCount: data.reference_num,
        scheme: data.scheme,
        version: data.version,
        callTime: data.callTime,
        source: data.source,
    };
}
function getSearchConfig(api) {
    const weiboCfg = api.config?.channels?.weibo;
    return {
        weiboSearchEndpoint: readOptionalNonBlankString(weiboCfg?.weiboSearchEndpoint),
        appId: readOptionalNonBlankString(weiboCfg?.appId),
        appSecret: readOptionalNonBlankString(weiboCfg?.appSecret),
        tokenEndpoint: readOptionalNonBlankString(weiboCfg?.tokenEndpoint),
        enabled: weiboCfg?.weiboSearchEnabled !== false,
    };
}
// ============ Tool Registration ============
export function registerWeiboSearchTools(api) {
    const searchCfg = getSearchConfig(api);
    // 检查是否禁用了搜索工具
    if (!searchCfg.enabled) {
        api.logger.debug?.("weibo_search: Search tool disabled, skipping registration");
        return;
    }
    // 检查是否配置了认证信息
    if (!searchCfg.appId || !searchCfg.appSecret) {
        api.logger.debug?.("weibo_search: appId or appSecret not configured, search tool disabled");
        return;
    }
    const appId = searchCfg.appId;
    const appSecret = searchCfg.appSecret;
    api.registerTool(() => ({
        name: "weibo_search",
        label: "Weibo Search",
        description: "微博智搜工具，通过关键词获取微博智搜内容。使用此工具获取数据后，必须使用查询关键词以及返回的 `callTime` 和 `source` 字段内容注明数据来源, 格式: 关键词: {query}， 2026-03-12 12:00，来自于微博智搜。查询结果可直接使用",
        parameters: WeiboSearchSchema,
        async execute(_toolCallId, params) {
            const p = params;
            try {
                // 获取有效的 token（使用共享的 token 工具）
                const token = await getValidWeiboToken(appId, appSecret, searchCfg.tokenEndpoint);
                const result = await searchWeibo(p.query, token, searchCfg.weiboSearchEndpoint);
                return json(formatSearchResult(result));
            }
            catch (err) {
                return json({
                    error: err instanceof Error ? err.message : String(err),
                });
            }
        },
    }), { name: "weibo_search" });
}
//# sourceMappingURL=weibo-search.js.map