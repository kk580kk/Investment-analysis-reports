import type { OpenClawConfig } from "openclaw/plugin-sdk/core";
import type { RuntimeEnv } from "openclaw/plugin-sdk/runtime-env";
import type { WeiboRuntimeStatusPatch } from "./types.js";
export type MonitorWeiboOpts = {
    config?: OpenClawConfig;
    runtime?: RuntimeEnv;
    abortSignal?: AbortSignal;
    accountId?: string;
    statusSink?: (patch: WeiboRuntimeStatusPatch) => void;
};
export declare function monitorWeiboProvider(opts?: MonitorWeiboOpts): Promise<void>;
export declare function stopWeiboMonitor(accountId?: string): void;
export declare function reconnectWeiboMonitor(accountId?: string): Promise<void>;
//# sourceMappingURL=monitor.d.ts.map