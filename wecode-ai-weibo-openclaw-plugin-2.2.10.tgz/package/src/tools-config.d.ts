import type { WeiboToolsConfig } from "./types.js";
export type ResolvedWeiboToolsConfig = Required<{
    search: boolean;
    myWeibo: boolean;
    hotSearch: boolean;
}>;
/**
 * Resolve tools configuration with defaults.
 * Missing values default to true (enabled).
 */
export declare function resolveToolsConfig(tools: WeiboToolsConfig | undefined): ResolvedWeiboToolsConfig;
/**
 * Check if any account has a specific tool enabled.
 * Used to determine whether to register a tool at all.
 */
export declare function resolveAnyEnabledWeiboToolsConfig(accounts: Array<{
    config: {
        tools?: WeiboToolsConfig;
    };
}>): ResolvedWeiboToolsConfig;
//# sourceMappingURL=tools-config.d.ts.map