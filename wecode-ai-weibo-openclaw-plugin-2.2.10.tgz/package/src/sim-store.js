import { randomUUID } from "crypto";
const DEFAULT_MAX_LOG_ENTRIES = 300;
const DEFAULT_MAX_MESSAGE_ENTRIES = 500;
function randomSuffix() {
    return randomUUID().replace(/-/g, "").slice(0, 16);
}
function boundedPush(arr, value, max) {
    arr.push(value);
    if (arr.length > max) {
        arr.splice(0, arr.length - max);
    }
}
export function createSimStore(options = {}) {
    const maxLogEntries = options.maxLogEntries ?? DEFAULT_MAX_LOG_ENTRIES;
    const maxMessageEntries = options.maxMessageEntries ?? DEFAULT_MAX_MESSAGE_ENTRIES;
    const credentialsByAppId = new Map();
    const tokenByValue = new Map();
    const latestTokenByAppId = new Map();
    const messages = [];
    const logs = [];
    function issueCredentials() {
        const createdAt = Date.now();
        const credential = registerCredentials(`app_${createdAt}_${randomSuffix()}`, `secret_${randomSuffix()}`, createdAt);
        return credential;
    }
    function registerCredentials(appId, appSecret, createdAt = Date.now()) {
        const credential = {
            appId: String(appId),
            appSecret: String(appSecret),
            createdAt,
        };
        credentialsByAppId.set(credential.appId, credential);
        return credential;
    }
    function listCredentials() {
        return Array.from(credentialsByAppId.values()).sort((a, b) => b.createdAt - a.createdAt);
    }
    function issueToken(appId, appSecret, ttlSeconds) {
        const credential = credentialsByAppId.get(appId);
        if (!credential || credential.appSecret !== appSecret) {
            throw new Error("Invalid credentials");
        }
        const prior = latestTokenByAppId.get(appId);
        if (prior) {
            tokenByValue.delete(prior);
        }
        const tokenInfo = {
            token: `wb_${randomSuffix()}_${Date.now()}`,
            appId,
            createdAt: Date.now(),
            expireIn: ttlSeconds,
        };
        tokenByValue.set(tokenInfo.token, tokenInfo);
        latestTokenByAppId.set(appId, tokenInfo.token);
        return tokenInfo;
    }
    function validateToken(token) {
        const tokenInfo = tokenByValue.get(token);
        if (!tokenInfo) {
            return null;
        }
        const expiresAt = tokenInfo.createdAt + tokenInfo.expireIn * 1000;
        if (Date.now() > expiresAt) {
            tokenByValue.delete(token);
            if (latestTokenByAppId.get(tokenInfo.appId) === token) {
                latestTokenByAppId.delete(tokenInfo.appId);
            }
            return null;
        }
        return tokenInfo;
    }
    function listTokens() {
        return Array.from(tokenByValue.values()).sort((a, b) => b.createdAt - a.createdAt);
    }
    function appendMessage(message) {
        const record = {
            ...message,
            id: message.id ?? `msg_${Date.now()}_${randomSuffix()}`,
        };
        boundedPush(messages, record, maxMessageEntries);
        return record;
    }
    function listMessages(limit = 50) {
        if (limit <= 0)
            return [];
        return messages.slice(-limit).reverse();
    }
    function appendLog(level, message, details) {
        const record = {
            id: `log_${Date.now()}_${randomSuffix()}`,
            level,
            message,
            details,
            timestamp: Date.now(),
        };
        boundedPush(logs, record, maxLogEntries);
        return record;
    }
    function listLogs(limit = 200) {
        if (limit <= 0)
            return [];
        return logs.slice(-limit).reverse();
    }
    return {
        registerCredentials,
        issueCredentials,
        listCredentials,
        issueToken,
        validateToken,
        listTokens,
        appendMessage,
        listMessages,
        appendLog,
        listLogs,
    };
}
//# sourceMappingURL=sim-store.js.map