import type { ResolvedWeiboAccount } from "./types.js";
export type WeiboTokenResponse = {
    data: {
        token: string;
        expire_in: number;
        uid: number;
    };
};
export type WeiboTokenResult = {
    token: string;
    expiresIn: number;
    acquiredAt: number;
    uid: number;
};
export declare const DEFAULT_TOKEN_ENDPOINT = "https://open-im.api.weibo.com/open/auth/ws_token";
/**
 * Get the base URL of the Weibo API from the token endpoint.
 * e.g. "https://open-im.api.weibo.com/open/auth/ws_token" → "https://open-im.api.weibo.com"
 *
 * Throws a clear configuration error if the resolved endpoint is not a valid absolute URL.
 */
export declare function getWeiboApiBaseUrl(tokenEndpoint?: string): string;
export declare class WeiboTokenFetchError extends Error {
    retryable: boolean;
    status?: number;
    constructor(message: string, options: {
        retryable: boolean;
        status?: number;
    });
}
export declare function formatWeiboTokenFetchErrorMessage(err: unknown): string | null;
export declare function isRetryableWeiboTokenFetchError(err: unknown): boolean | null;
export declare function fetchWeiboToken(account: ResolvedWeiboAccount, tokenEndpoint?: string): Promise<WeiboTokenResult>;
export declare function getCachedToken(accountId: string, fingerprint?: string): WeiboTokenResult | undefined;
export declare function clearTokenCache(accountId?: string): void;
export declare function getValidToken(account: ResolvedWeiboAccount, tokenEndpoint?: string): Promise<string>;
//# sourceMappingURL=token.d.ts.map