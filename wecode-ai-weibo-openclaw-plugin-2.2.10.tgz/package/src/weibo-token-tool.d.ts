import type { OpenClawPluginApi } from "openclaw/plugin-sdk/core";
import { type Static } from "@sinclair/typebox";
export declare const WeiboTokenSchema: import("@sinclair/typebox").TObject<{}>;
export type WeiboTokenParams = Static<typeof WeiboTokenSchema>;
export type WeiboTokenCache = {
    token: string;
    acquiredAt: number;
    expiresIn: number;
};
/**
 * 获取微博 API token
 * 通过 https://open-im.api.weibo.com/open/auth/ws_token 获取
 * token 过期时间为 2 小时
 */
export declare function fetchWeiboToken(appId: string, appSecret: string, tokenEndpoint?: string): Promise<WeiboTokenCache>;
/**
 * 检查 token 是否有效
 */
export declare function isTokenValid(tokenCache: WeiboTokenCache | null): boolean;
/**
 * 获取有效的微博 token
 * 如果缓存的 token 未过期则返回缓存，否则重新获取
 */
export declare function getValidWeiboToken(appId: string, appSecret: string, tokenEndpoint?: string): Promise<string>;
/**
 * 获取当前缓存的 token 信息
 */
export declare function getCachedToken(): WeiboTokenCache | null;
/**
 * 清除 token 缓存
 */
export declare function clearWeiboTokenCache(): void;
export type WeiboTokenConfig = {
    /** App ID，用于获取 token */
    appId?: string;
    /** App Secret，用于获取 token */
    appSecret?: string;
    /** Token 端点，默认为 https://open-im.api.weibo.com/open/auth/ws_token */
    tokenEndpoint?: string;
    /** 是否启用 token 工具，默认为 true */
    enabled?: boolean;
};
export declare function getWeiboTokenConfig(api: OpenClawPluginApi): WeiboTokenConfig;
export declare function registerWeiboTokenTools(api: OpenClawPluginApi): void;
//# sourceMappingURL=weibo-token-tool.d.ts.map