import type { OpenClawConfig } from "openclaw/plugin-sdk/core";
import type { ResolvedWeiboAccount } from "./types.js";
export declare function resolveWeiboAccount({ cfg, accountId, }: {
    cfg: OpenClawConfig;
    accountId?: string;
}): ResolvedWeiboAccount;
export declare function listWeiboAccountIds(cfg: OpenClawConfig): string[];
export declare function resolveDefaultWeiboAccountId(cfg: OpenClawConfig): string;
export declare function listEnabledWeiboAccounts(cfg: OpenClawConfig): ResolvedWeiboAccount[];
//# sourceMappingURL=accounts.d.ts.map