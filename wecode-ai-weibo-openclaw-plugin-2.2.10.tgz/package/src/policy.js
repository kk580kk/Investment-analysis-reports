export function resolveWeiboAllowlistMatch({ userId, allowFrom, }) {
    if (allowFrom.includes("*"))
        return true;
    return allowFrom.includes(userId);
}
//# sourceMappingURL=policy.js.map