import type { ResolvedWeiboAccount } from "./types.js";
export declare function getWeiboConnectionFingerprint(account: ResolvedWeiboAccount): string;
export declare function getWeiboTokenFingerprint(account: ResolvedWeiboAccount, tokenEndpoint?: string): string;
//# sourceMappingURL=fingerprint.d.ts.map