let weiboRuntime;
export function setWeiboRuntime(runtime) {
    weiboRuntime = runtime;
}
export function getWeiboRuntime() {
    if (!weiboRuntime) {
        throw new Error("Weibo runtime not initialized");
    }
    return weiboRuntime;
}
//# sourceMappingURL=runtime.js.map