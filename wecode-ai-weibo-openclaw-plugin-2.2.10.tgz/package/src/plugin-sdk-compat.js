function buildAgentMediaPayloadFallback(mediaList) {
    const normalized = mediaList.filter((item) => typeof item.path === "string" && item.path.trim().length > 0);
    if (normalized.length === 0) {
        return {};
    }
    const paths = normalized.map((item) => item.path);
    const types = normalized.map((item) => item.contentType ?? undefined).filter((value) => typeof value === "string");
    const payload = {
        MediaPath: paths[0],
        MediaPaths: paths,
        MediaUrl: paths[0],
        MediaUrls: paths,
    };
    if (types.length > 0) {
        payload.MediaType = types[0];
        payload.MediaTypes = types;
    }
    return payload;
}
function waitUntilAbortFallback(abortSignal) {
    if (!abortSignal) {
        return new Promise(() => undefined);
    }
    if (abortSignal.aborted) {
        return Promise.resolve();
    }
    return new Promise((resolve) => {
        abortSignal.addEventListener("abort", () => resolve(), { once: true });
    });
}
export function buildAgentMediaPayloadCompat(mediaList) {
    return buildAgentMediaPayloadFallback(mediaList);
}
export function waitUntilAbortCompat(abortSignal) {
    return waitUntilAbortFallback(abortSignal);
}
//# sourceMappingURL=plugin-sdk-compat.js.map