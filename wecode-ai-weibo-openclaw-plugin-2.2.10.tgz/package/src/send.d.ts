import type { OpenClawConfig } from "openclaw/plugin-sdk/core";
import type { WeiboSendResult } from "./types.js";
export type SendWeiboMessageParams = {
    cfg: OpenClawConfig;
    to: string;
    text: string;
    accountId?: string;
    messageId?: string;
    chunkId?: number;
    done?: boolean;
};
export declare function generateWeiboMessageId(): string;
export declare function sendMessageWeibo(params: SendWeiboMessageParams): Promise<WeiboSendResult>;
export type SendFileDmWeiboResult = {
    messageId: string;
    chatId: string;
    fid: number;
};
/**
 * Send a file DM via Weibo HTTP API.
 *
 * API: POST /open/dm/send_file?token=xxx&fileName=xxx
 * Body: raw binary file data (application/octet-stream)
 *
 * The recipient (toUid) is resolved server-side from the token.
 * The token encodes both the assistant UID (sender) and the target user UID (recipient).
 *
 * Response: { code: 0, data: { fid: 123456, message_id: "xxx" } }
 */
export declare function sendFileDmWeibo(params: {
    cfg: OpenClawConfig;
    to: string;
    buffer: Buffer;
    fileName: string;
    accountId?: string;
}): Promise<SendFileDmWeiboResult>;
//# sourceMappingURL=send.d.ts.map