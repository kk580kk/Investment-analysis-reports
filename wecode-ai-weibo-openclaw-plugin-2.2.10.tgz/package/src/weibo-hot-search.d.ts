import type { OpenClawPluginApi } from "openclaw/plugin-sdk/core";
import { type Static } from "@sinclair/typebox";
export declare const WeiboHotSearchSchema: import("@sinclair/typebox").TObject<{
    category: import("@sinclair/typebox").TString;
    count: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
}>;
export type WeiboHotSearchParams = Static<typeof WeiboHotSearchSchema>;
/**
 * 热搜榜 API 响应结构
 * API: https://open-im.api.weibo.com/open/weibo/hot_search
 */
export type WeiboHotSearchApiResponse = {
    code: number;
    message: string;
    data: {
        callTime?: string;
        source?: string;
        data: WeiboHotSearchItem[];
    };
};
export type WeiboHotSearchItem = {
    cat: string;
    id: number;
    word: string;
    num: number;
    flag: number;
    app_query_link: string;
    h5_query_link: string;
    flag_link: string;
};
export type WeiboHotSearchConfig = {
    /** 热搜 API 端点，默认为 open-im.api.weibo.com */
    weiboHotSearchEndpoint?: string;
    /** App ID，用于获取 token */
    appId?: string;
    /** App Secret，用于获取 token */
    appSecret?: string;
    /** Token 端点，默认为 https://open-im.api.weibo.com/open/auth/ws_token */
    tokenEndpoint?: string;
    /** 是否启用热搜工具，默认为 true */
    enabled?: boolean;
};
export declare function registerWeiboHotSearchTools(api: OpenClawPluginApi): void;
//# sourceMappingURL=weibo-hot-search.d.ts.map