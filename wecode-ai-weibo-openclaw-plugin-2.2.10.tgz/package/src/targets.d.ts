export declare function normalizeWeiboTarget(target: string): string;
export declare function looksLikeWeiboId(str: string): boolean;
export declare function formatWeiboTarget(userId: string): string;
//# sourceMappingURL=targets.d.ts.map