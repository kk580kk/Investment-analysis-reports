import type { OpenClawPluginApi } from "openclaw/plugin-sdk/core";
import { type Static } from "@sinclair/typebox";
export declare const WeiboStatusSchema: import("@sinclair/typebox").TObject<{
    count: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
}>;
export type WeiboStatusParams = Static<typeof WeiboStatusSchema>;
/**
 * 用户信息结构（简化版）
 */
export type WeiboStatusUser = {
    screen_name: string;
};
/**
 * 微博状态项结构
 */
export type WeiboStatusItem = {
    /** 微博 ID */
    id: number;
    /** 微博 MID */
    mid: string;
    /** 微博内容 */
    text: string;
    /** 发布时间 */
    created_at: string;
    /** 是否有图片 */
    has_image: boolean;
    /** 图片列表（图片ID数组） */
    images?: string[];
    /** 图片数量 */
    pic_num?: number;
    /** 评论数 */
    comments_count: number;
    /** 转发数 */
    reposts_count: number;
    /** 点赞数 */
    attitudes_count: number;
    /** 用户信息 */
    user: WeiboStatusUser;
    /** 转发的原微博 */
    repost?: WeiboStatusItem;
};
/**
 * 用户微博 API 响应结构
 */
export type WeiboStatusApiResponse = {
    code: number;
    message: string;
    data: {
        statuses: WeiboStatusItem[];
        total_number: number;
    };
};
export type WeiboStatusConfig = {
    weiboStatusEndpoint?: string;
    appId?: string;
    appSecret?: string;
    tokenEndpoint?: string;
    enabled?: boolean;
};
export declare function registerWeiboStatusTools(api: OpenClawPluginApi): void;
//# sourceMappingURL=weibo-status.d.ts.map