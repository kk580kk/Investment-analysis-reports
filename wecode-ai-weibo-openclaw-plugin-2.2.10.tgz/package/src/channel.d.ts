import type { ChannelPlugin } from "openclaw/plugin-sdk/core";
import type { ResolvedWeiboAccount } from "./types.js";
export declare const weiboPlugin: ChannelPlugin<ResolvedWeiboAccount>;
//# sourceMappingURL=channel.d.ts.map