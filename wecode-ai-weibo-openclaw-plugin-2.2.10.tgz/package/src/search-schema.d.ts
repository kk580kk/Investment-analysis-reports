import { type Static } from "@sinclair/typebox";
export declare const WeiboSearchSchema: import("@sinclair/typebox").TObject<{
    query: import("@sinclair/typebox").TString;
}>;
export type WeiboSearchParams = Static<typeof WeiboSearchSchema>;
//# sourceMappingURL=search-schema.d.ts.map