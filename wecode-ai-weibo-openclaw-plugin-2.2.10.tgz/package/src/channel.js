import { resolveWeiboAccount, listWeiboAccountIds, resolveDefaultWeiboAccountId, } from "./accounts.js";
import { weiboOutbound } from "./outbound.js";
import { normalizeWeiboTarget, looksLikeWeiboId } from "./targets.js";
import { sendMessageWeibo } from "./send.js";
import { monitorWeiboProvider } from "./monitor.js";
const DEFAULT_ACCOUNT_ID = "default";
const PAIRING_APPROVED_MESSAGE = "✓ You have been approved to chat with this agent.";
const meta = {
    id: "weibo",
    label: "Weibo",
    selectionLabel: "Weibo (微博)",
    docsPath: "/channels/weibo",
    docsLabel: "weibo",
    blurb: "Weibo direct message channel.",
    order: 80,
};
export const weiboPlugin = {
    id: "weibo",
    meta,
    pairing: {
        idLabel: "weiboUserId",
        normalizeAllowEntry: (entry) => entry.replace(/^user:/i, ""),
        notifyApproval: async ({ cfg, id }) => {
            await sendMessageWeibo({
                cfg,
                to: id,
                text: PAIRING_APPROVED_MESSAGE,
            });
        },
    },
    capabilities: {
        chatTypes: ["direct"],
        polls: false,
        threads: false,
        media: true,
        reactions: false,
        edit: false,
        reply: false,
    },
    agentPrompt: {
        messageToolHints: () => [
            "- Weibo targeting: omit `target` to reply to the current conversation. Explicit targets: `user:userId`.",
        ],
    },
    reload: { configPrefixes: ["channels.weibo"] },
    configSchema: {
        schema: {
            type: "object",
            additionalProperties: false,
            properties: {
                enabled: { type: "boolean", default: true, title: "启用账号", description: "是否启用此微博账号" },
                appId: { type: "string", title: "App ID", description: "App ID" },
                appSecret: { type: "string", title: "App Secret", description: "App Secret" },
                wsEndpoint: { type: "string", format: "uri", default: "ws://open-im.api.weibo.com/ws/stream", title: "WebSocket 地址", description: "微博 WebSocket 服务地址" },
                tokenEndpoint: { type: "string", format: "uri", default: "https://open-im.api.weibo.com/open/auth/ws_token", title: "Token 服务地址", description: "获取 WebSocket Token 的服务地址" },
                dmPolicy: { type: "string", enum: ["open", "pairing"], default: "open", title: "私信策略", description: "open=允许所有人私信, pairing=仅允许配对用户" },
                allowFrom: { type: "array", items: { type: "string" }, title: "允许列表", description: "允许发送私信的用户 ID 列表（白名单）" },
                textChunkLimit: { type: "integer", minimum: 1, title: "文本分片限制", description: "单条消息最大字符数，超出后自动分片" },
                chunkMode: { type: "string", enum: ["length", "newline", "raw"], default: "raw", title: "分片模式", description: "newline=按段落分片, length=按字符数分片, raw=转发上游分片" },
                accounts: {
                    type: "object",
                    additionalProperties: {
                        type: "object",
                        properties: {
                            enabled: { type: "boolean", default: true, title: "启用账号", description: "是否启用此微博账号" },
                            name: { type: "string", title: "账号名称", description: "账号显示名称（可选）" },
                            appId: { type: "string", title: "App ID", description: "App ID" },
                            appSecret: { type: "string", title: "App Secret", description: "App Secret" },
                            wsEndpoint: { type: "string", default: "ws://open-im.api.weibo.com/ws/stream", title: "WebSocket 地址", description: "微博 WebSocket 服务地址" },
                            tokenEndpoint: { type: "string", default: "https://open-im.api.weibo.com/open/auth/ws_token", title: "Token 服务地址", description: "获取 WebSocket Token 的服务地址" },
                            textChunkLimit: { type: "integer", minimum: 1, title: "文本分片限制", description: "单条消息最大字符数，超出后自动分片" },
                            chunkMode: { type: "string", enum: ["length", "newline", "raw"], default: "raw", title: "分片模式", description: "newline=按段落分片, length=按字符数分片, raw=转发上游分片" },
                        },
                    },
                },
            },
        },
    },
    config: {
        listAccountIds: (cfg) => listWeiboAccountIds(cfg),
        resolveAccount: (cfg, accountId) => resolveWeiboAccount({ cfg, accountId: accountId ?? DEFAULT_ACCOUNT_ID }),
        defaultAccountId: (cfg) => resolveDefaultWeiboAccountId(cfg),
        setAccountEnabled: ({ cfg, accountId, enabled, }) => {
            const isDefault = accountId === DEFAULT_ACCOUNT_ID;
            if (isDefault) {
                return {
                    ...cfg,
                    channels: {
                        ...cfg.channels,
                        weibo: {
                            ...cfg.channels?.weibo,
                            enabled,
                        },
                    },
                };
            }
            const weiboCfg = cfg.channels?.weibo;
            return {
                ...cfg,
                channels: {
                    ...cfg.channels,
                    weibo: {
                        ...weiboCfg,
                        accounts: {
                            ...weiboCfg?.accounts,
                            [accountId]: {
                                ...weiboCfg?.accounts?.[accountId],
                                enabled,
                            },
                        },
                    },
                },
            };
        },
        deleteAccount: ({ cfg, accountId, }) => {
            const isDefault = accountId === DEFAULT_ACCOUNT_ID;
            if (isDefault) {
                const next = { ...cfg };
                const nextChannels = { ...cfg.channels };
                delete nextChannels.weibo;
                if (Object.keys(nextChannels).length > 0) {
                    next.channels = nextChannels;
                }
                else {
                    delete next.channels;
                }
                return next;
            }
            const weiboCfg = cfg.channels?.weibo;
            const accounts = { ...weiboCfg?.accounts };
            delete accounts[accountId];
            return {
                ...cfg,
                channels: {
                    ...cfg.channels,
                    weibo: {
                        ...weiboCfg,
                        accounts: Object.keys(accounts).length > 0 ? accounts : undefined,
                    },
                },
            };
        },
        isConfigured: (account) => account.configured,
        describeAccount: (account) => ({
            accountId: account.accountId,
            enabled: account.enabled,
            configured: account.configured,
            name: account.name,
            appId: account.appId,
        }),
        resolveAllowFrom: ({ cfg, accountId, }) => {
            const account = resolveWeiboAccount({ cfg, accountId: accountId ?? DEFAULT_ACCOUNT_ID });
            return (account.config?.allowFrom ?? [])
                .map((entry) => String(entry).trim())
                .filter(Boolean);
        },
        formatAllowFrom: ({ allowFrom, }) => allowFrom
            .map((entry) => String(entry).trim())
            .filter(Boolean),
    },
    security: {
        collectWarnings: () => [],
    },
    setup: {
        resolveAccountId: () => DEFAULT_ACCOUNT_ID,
        applyAccountConfig: ({ cfg, accountId, }) => {
            const isDefault = !accountId || accountId === DEFAULT_ACCOUNT_ID;
            if (isDefault) {
                return {
                    ...cfg,
                    channels: {
                        ...cfg.channels,
                        weibo: {
                            ...cfg.channels?.weibo,
                            enabled: true,
                        },
                    },
                };
            }
            const weiboCfg = cfg.channels?.weibo;
            return {
                ...cfg,
                channels: {
                    ...cfg.channels,
                    weibo: {
                        ...weiboCfg,
                        accounts: {
                            ...weiboCfg?.accounts,
                            [accountId]: {
                                ...weiboCfg?.accounts?.[accountId],
                                enabled: true,
                            },
                        },
                    },
                },
            };
        },
    },
    messaging: {
        normalizeTarget: (raw) => {
            const result = normalizeWeiboTarget(raw);
            return result || undefined;
        },
        targetResolver: {
            looksLikeId: looksLikeWeiboId,
            hint: "<userId>",
        },
    },
    directory: {
        self: async () => null,
        listPeers: async () => [],
        listGroups: async () => [],
        listPeersLive: async () => [],
        listGroupsLive: async () => [],
    },
    outbound: weiboOutbound,
    status: {
        defaultRuntime: {
            accountId: DEFAULT_ACCOUNT_ID,
            running: false,
            connected: false,
            mode: "idle",
            reconnectAttempts: 0,
            lastConnectedAt: null,
            lastDisconnect: null,
            lastStartAt: null,
            lastStopAt: null,
            lastInboundAt: null,
            lastOutboundAt: null,
            lastError: null,
            port: null,
        },
        buildChannelSummary: ({ snapshot }) => ({
            configured: snapshot.configured ?? false,
            running: snapshot.running ?? false,
            connected: snapshot.connected ?? false,
            connectionState: snapshot.connectionState
                ?? snapshot.mode
                ?? null,
            reconnectAttempts: snapshot.reconnectAttempts ?? 0,
            nextRetryAt: snapshot.nextRetryAt ?? null,
            lastConnectedAt: snapshot.lastConnectedAt ?? null,
            lastDisconnect: snapshot.lastDisconnect ?? null,
            lastStartAt: snapshot.lastStartAt ?? null,
            lastStopAt: snapshot.lastStopAt ?? null,
            lastInboundAt: snapshot.lastInboundAt ?? null,
            lastOutboundAt: snapshot.lastOutboundAt ?? null,
            lastError: snapshot.lastError ?? null,
            port: snapshot.port ?? null,
        }),
        probeAccount: async () => ({ ok: true }),
        buildAccountSnapshot: ({ account, runtime }) => {
            const runtimeRecord = runtime;
            const disconnect = runtime?.lastDisconnect;
            return {
                accountId: account.accountId,
                enabled: account.enabled,
                configured: account.configured,
                name: account.name,
                appId: account.appId,
                running: runtime?.running ?? false,
                connected: runtime?.connected ?? false,
                mode: runtimeRecord?.connectionState
                    ?? runtime?.mode
                    ?? null,
                reconnectAttempts: runtime?.reconnectAttempts ?? 0,
                lastConnectedAt: runtime?.lastConnectedAt ?? null,
                lastDisconnect: disconnect && typeof disconnect === "object"
                    ? {
                        at: Number(disconnect.at ?? Date.now()),
                        status: typeof disconnect.code === "number" ? disconnect.code : undefined,
                        error: typeof disconnect.reason === "string" ? disconnect.reason : undefined,
                    }
                    : disconnect ?? null,
                lastStartAt: runtime?.lastStartAt ?? null,
                lastStopAt: runtime?.lastStopAt ?? null,
                lastInboundAt: runtime?.lastInboundAt ?? null,
                lastOutboundAt: runtime?.lastOutboundAt ?? null,
                lastError: runtime?.lastError ?? null,
                port: runtime?.port ?? null,
                connectionState: runtimeRecord?.connectionState
                    ?? runtime?.mode
                    ?? null,
                nextRetryAt: runtimeRecord?.nextRetryAt ?? null,
            };
        },
    },
    gateway: {
        startAccount: async (ctx) => {
            ctx.setStatus({
                accountId: ctx.accountId,
                port: null,
                running: true,
                connected: false,
                mode: "connecting",
                lastStartAt: Date.now(),
                lastStopAt: null,
                lastError: null,
            });
            ctx.log?.info(`starting weibo[${ctx.accountId}] WebSocket`);
            return monitorWeiboProvider({
                config: ctx.cfg,
                runtime: ctx.runtime,
                abortSignal: ctx.abortSignal,
                accountId: ctx.accountId,
                statusSink: (patch) => ctx.setStatus({
                    accountId: ctx.accountId,
                    port: null,
                    ...patch,
                    mode: patch.connectionState
                        ?? ctx.getStatus().mode,
                }),
            });
        },
    },
};
//# sourceMappingURL=channel.js.map