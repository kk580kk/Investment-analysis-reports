export function normalizeWeiboTarget(target) {
    const trimmed = target.trim();
    if (!trimmed)
        return "";
    if (trimmed.startsWith("user:"))
        return trimmed;
    return `user:${trimmed}`;
}
export function looksLikeWeiboId(str) {
    return /^\d+$/.test(str.trim());
}
export function formatWeiboTarget(userId) {
    return `user:${userId}`;
}
//# sourceMappingURL=targets.js.map