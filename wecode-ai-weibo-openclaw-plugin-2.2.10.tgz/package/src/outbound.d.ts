import type { ChannelOutboundAdapter } from "openclaw/plugin-sdk/channel-runtime";
export declare const weiboOutbound: ChannelOutboundAdapter;
//# sourceMappingURL=outbound.d.ts.map