import type { OpenClawConfig } from "openclaw/plugin-sdk/core";
import type { RuntimeEnv } from "openclaw/plugin-sdk/runtime-env";
import type { WeiboInboundAttachmentPart, WeiboMessageContext, WeiboResponseMessageInputItem } from "./types.js";
export type WeiboMessageEvent = {
    type: "message";
    payload: {
        messageId: string;
        fromUserId: string;
        text?: string;
        timestamp?: number;
        input?: WeiboResponseMessageInputItem[];
    };
};
export type NormalizedWeiboInboundInput = {
    text: string;
    images: WeiboInboundAttachmentPart[];
    files: WeiboInboundAttachmentPart[];
};
export declare function normalizeWeiboInboundInput(event: WeiboMessageEvent): NormalizedWeiboInboundInput;
export type HandleWeiboMessageParams = {
    cfg: OpenClawConfig;
    event: WeiboMessageEvent;
    accountId: string;
    runtime?: RuntimeEnv;
};
export declare function handleWeiboMessage(params: HandleWeiboMessageParams): Promise<WeiboMessageContext | null>;
//# sourceMappingURL=bot.d.ts.map