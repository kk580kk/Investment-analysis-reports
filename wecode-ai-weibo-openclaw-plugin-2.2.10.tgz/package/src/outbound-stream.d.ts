export type WeiboChunkMode = "length" | "newline" | "raw";
type StreamDebugFn = (tag: string, data?: Record<string, unknown>) => void;
export type WeiboOutboundEmitFn = (params: {
    text: string;
    done: boolean;
    source: "partial" | "deliver" | "settled";
}) => Promise<void>;
type CreateWeiboOutboundStreamParams = {
    chunkMode: WeiboChunkMode;
    textChunkLimit: number;
    emit: WeiboOutboundEmitFn;
    chunkTextWithMode: (text: string, limit: number, mode: "length" | "newline") => Iterable<string>;
    streamDebug?: StreamDebugFn;
};
type StreamStateSnapshot = {
    hasSeenPartial: boolean;
    hasEmittedChunks: boolean;
    hasEmittedDone: boolean;
    newlineBufferLen: number;
    pendingDeliverBufferLen: number;
};
export declare function createWeiboOutboundStream(params: CreateWeiboOutboundStreamParams): {
    pushPartialSnapshot(snapshot: string): Promise<void>;
    pushDeliverText(params: {
        text: string;
        isFinal: boolean;
    }): Promise<void>;
    settle(): Promise<void>;
    snapshot(): StreamStateSnapshot;
};
export {};
//# sourceMappingURL=outbound-stream.d.ts.map