import type { OpenClawPluginApi } from "openclaw/plugin-sdk/core";
export { monitorWeiboProvider } from "./src/monitor.js";
export { sendMessageWeibo } from "./src/send.js";
export { weiboPlugin } from "./src/channel.js";
declare const plugin: {
    id: string;
    name: string;
    description: string;
    configSchema: {
        type: "object";
        properties: {};
    };
    register(api: OpenClawPluginApi): void;
};
export default plugin;
//# sourceMappingURL=index.d.ts.map