---
name: weibo-creator
description: |
  微博创作者数据工具。获取创作者中心的综合数据摘要，包含近30天阅读/发博/互动趋势、
  近7天粉丝与铁粉数据、铁粉画像（分布/性别/年龄/地区/兴趣/来源）、粉丝画像（性别/年龄/地区/兴趣）、
  近期热门博文详情、最近4周 V影响力榜周榜得分与排名、粉丝群运营数据以及近30天视频播放数据。
  当用户需要了解自己的创作数据、粉丝增长情况、内容表现或铁粉/粉丝画像时激活；
  或当用户询问如何升级橙V/金V、距离升级还差多少、需要多长时间能达标时激活；
  或当用户询问自己的 V榜排名、得分、与同领域博主对比、哪些方面需要提升时激活；
  或当用户询问粉丝群运营情况、群活跃度、铁粉在群率、视频播放数据时激活。
metadata:
  version: "1.0.4"
---

# 微博创作者数据工具

本技能通过脚本 `scripts/weibo-creator.js` 调用创作者中心接口，一次性获取多维度创作数据摘要；并内置金橙V升级分析能力，可根据数据自动计算达标差距与策略规划。

## 脚本调用方式

```bash
node scripts/weibo-creator.js summary --token=<token>
```

**参数说明**：

| 参数 | 必填 | 说明 |
|------|------|------|
| `--token` | 是 | 微博 API 访问令牌，通过 `weibo_token` 工具获取 |

---

## 返回数据结构

接口路径：`GET /open/creator/summary`

返回的 `data` 字段为 `CreatorSummary` 对象，包含以下维度：

### 1. 近30天阅读数据

#### `data.readTrend30Days` — 每日阅读趋势（数组，T-1 至 T-30，共30条）

| 字段 | 类型 | 说明 |
|------|------|------|
| `date` | string | 日期（格式：yyyy-MM-dd） |
| `totalReadCount` | number | 当日总排水阅读数 |

#### `data.readSourceSummary30Days` — 近30日分场景阅读汇总

| 字段 | 类型 | 说明 |
|------|------|------|
| `followReadCount` | number | 关注流阅读数（私域流量） |
| `followReadRate` | string | 关注流阅读占比（%，如 "55.8"） |
| `profileReadCount` | number | 个人主页阅读数（私域流量） |
| `profileReadRate` | string | 个人主页阅读占比（%） |
| `searchReadCount` | number | 搜索阅读数（公域流量） |
| `searchReadRate` | string | 搜索阅读占比（%） |
| `hotReadCount` | number | 推荐阅读数（公域流量） |
| `hotReadRate` | string | 推荐阅读占比（%） |
| `othersReadCount` | number | 其他阅读数 |
| `othersReadRate` | string | 其他阅读占比（%） |

> 关注流 + 个人主页 = 私域流量；搜索 + 推荐 = 公域流量。

---

### 2. 近30天发博活跃数据

#### `data.postTrend30Days` — 每日发博趋势（数组，T-1 至 T-30，共30条）

| 字段 | 类型 | 说明 |
|------|------|------|
| `date` | string | 日期（格式：yyyy-MM-dd） |
| `statusCount` | number | 当日发博数 |

---

### 3. 近30天互动数据

#### `data.interactTrend30Days` — 每日互动趋势（数组，T-1 至 T-30，共30条）

| 字段 | 类型 | 说明 |
|------|------|------|
| `date` | string | 日期（格式：yyyy-MM-dd） |
| `repostCount` | number | 当日收到的转发数 |
| `commentCount` | number | 当日收到的评论数 |
| `likeCount` | number | 当日收到的点赞数 |

---

### 4. 近7天粉丝&铁粉数据

#### `data.fanTrend7Days` — 每日粉丝&铁粉趋势（数组，T-1 至 T-7，共7条）

| 字段 | 类型 | 说明 |
|------|------|------|
| `date` | string | 日期（格式：yyyy-MM-dd） |
| `fansTotal` | number | 当日粉丝总数（仅昨日有值，其余可能为 null） |
| `newFansCount` | number | 当日新增粉丝数 |
| `bigFanTotal` | number | 当日铁粉总数 |
| `newBigFanCount` | number | 当日新增铁粉数 |

---

### 5. 铁粉画像数据

#### `data.bigFanPortrait` — 铁粉画像（截止昨日 T-1 的当前值）

| 字段 | 类型 | 说明 |
|------|------|------|
| `pyramid` | object | 铁粉分布：key 为 "钻粉"/"金粉"/"铁粉"，value 为百分比字符串（如 "2.1"） |
| `gender` | object | 性别分布：key 为 "男性"/"女性"，value 为百分比字符串 |
| `age` | object | 年龄分布：key 为 "小于18"/"18-24"/"25-34"/"35-44"/"大于44"，value 为百分比字符串 |
| `province` | object | 地区分布 TOP5：key 为省份名，value 为百分比字符串 |
| `tags` | object | 兴趣分布 TOP5：key 为兴趣标签，value 为百分比字符串 |
| `source` | object | 来源场景 TOP5：key 为来源名称，value 为百分比字符串 |

---

### 6. 近期热门博文数据

#### `data.topBlogs` — 热门博文列表（最多5条）

| 字段 | 类型 | 说明 |
|------|------|------|
| `mid` | string | 博文 mid |
| `weiboText` | string | 博文正文（截断预览） |
| `createTimeText` | string | 发博日期（格式：yyyy-MM-dd） |
| `hasVid` | number | 是否含视频（0=否 / 1=是） |
| `readTotal` | number | 单条博文阅读总数 |
| `readFans` | number | 单条博文粉丝阅读数 |
| `readNonfans` | number | 单条博文非粉丝阅读数 |
| `repostTotal` | number | 单条博文转发总数 |
| `commentTotal` | number | 单条博文评论总数 |
| `likeTotal` | number | 单条博文赞总数 |
| `interactTotal` | number | 单条博文互动总数（= 转发 + 评论 + 点赞） |

---

### 7. V榜周榜数据

#### `data.rankDetails` — KOL 周度排名评分列表（数组，最近4次周榜，最多4条）

每条记录对应一个自然周的榜单数据：

| 字段 | 类型 | 说明 |
|------|------|------|
| `dt` | string | 数据日期（格式：yyyyMMdd，如 "20260427"） |
| `fieldId` | number | 领域 ID |
| `fieldName` | string | 领域名称（如 "科技"） |
| `period` | string | 周期描述（如 "2026年第18周"） |
| `scorePeriod` | string | 评分周期（如 "04/27-05/03"） |
| `rank` | string | 本周排名 |
| `totalScore` | string | 综合总分 |
| `details` | array | 各维度评分明细（共9项，见下表） |

#### `data.rankDetails[].details` — 各维度评分明细（9项）

每项结构如下：

| 字段 | 类型 | 说明 |
|------|------|------|
| `name` | string | 指标名称 |
| `score` | string | 用户自己的得分 |
| `fullScore` | string | 该项满分（无满分时为空字符串） |
| `avgScore` | string | 同领域同层级博主均值（无均值时为空字符串） |

9项指标的层级结构如下：

```
传播影响力得分
  ├── 私域流量得分
  ├── 公域流量得分
  └── 内容效率得分
内容吸引力得分
  ├── 被互动得分
  └── 粉丝吸引力得分
主动活跃度得分
  └── 主动活跃得分
```

> `details` 数组中共9项，按上述层级顺序排列，包含3个父级维度和6个子维度。

---

### 8. 粉丝群汇总数据

#### `data.groupSummary` — 粉丝群汇总数据

包含群成员活跃、互动、铁粉在群率、人数变化（近7天趋势）及成员构成分布（T-1）。

**近7日趋势字段**（每个字段均为数组，共7条，每条含 `date`（yyyyMMdd）和 `num`（指标值字符串））：

| 字段 | 说明 |
|------|------|
| `speakCountTrend` | 发言人数近7日趋势 |
| `openCountTrend` | 打开人数近7日趋势 |
| `avgSpeakTrend` | 人均发言条数近7日趋势 |
| `interactCountTrend` | 群成员互动量近7日趋势 |
| `readCountTrend` | 群成员阅读量近7日趋势 |
| `bigfanInRateTrend` | 铁粉在群率近7日趋势（%） |
| `memberTotalTrend` | 群成员总数近7日趋势 |
| `joinCountTrend` | 进群人数近7日趋势 |
| `leaveCountTrend` | 退群人数近7日趋势 |

**成员构成分布（T-1 当前值）**：

| 字段 | 类型 | 说明 |
|------|------|------|
| `coreFanRate` | string | 铁粉百分比（%，如 "24.2"） |
| `loveFanRate` | string | 真爱粉百分比（%，铁粉子分类） |
| `otherBigFanRate` | string | 其他铁粉百分比（%，铁粉子分类） |
| `otherFanRate` | string | 粉丝百分比（%） |
| `nonFanRate` | string | 非粉百分比（%） |

---

### 9. 单个粉丝群活跃数据

#### `data.groupDetails` — 单个粉丝群活跃数据列表（数组，每个群一条）

**T-1 当前值字段**：

| 字段 | 类型 | 说明 |
|------|------|------|
| `gid` | string | 粉丝群 ID |
| `name` | string | 粉丝群名称 |
| `genderRate` | object | 群内性别分布：key 为 "男"/"女"，value 为百分比整数字符串（如 "56"） |
| `bigfanRate` | string | 铁粉占比（T-1 日，%） |
| `loveFanRate` | string | 真爱粉占比（T-1 日，%） |

**近7日趋势字段**（每个字段均为数组，共7条，每条含 `date`（yyyy-MM-dd）和 `num`（指标值字符串））：

| 字段 | 说明 |
|------|------|
| `memberCountTrend` | 单个群成员人数近7日趋势 |
| `openCountTrend` | 单个群打开人数近7日趋势 |
| `speakCountTrend` | 单个群发言人数近7日趋势 |
| `speakTimesTrend` | 单个群发言条数近7日趋势 |
| `joinCountTrend` | 单个群进群人数近7日趋势 |

---

### 10. 近30天视频播放数据

#### `data.videoSummary` — 视频播放汇总数据

| 字段 | 类型 | 说明 |
|------|------|------|
| `trendLast30Days` | array | 近30天视频播放趋势（共30条，见下表） |
| `last7Days` | object | 近7天视频汇总数据（见下表） |
| `yesterday` | object | 昨日视频数据（含较前日增量，见下表） |

**`trendLast30Days[]` — 每日视频数据**：

| 字段 | 类型 | 说明 |
|------|------|------|
| `date` | string | 日期（格式：yyyy-MM-dd） |
| `uploadCount` | number | 当日视频发布量 |
| `playCount` | number | 当日视频播放量 |
| `playDuraCount` | number | 当日视频播放时长（秒） |
| `repostCount` | number | 当日视频转发量 |
| `commentCount` | number | 当日视频评论量 |
| `likeCount` | number | 当日视频点赞量 |

**`last7Days` — 近7天汇总**（字段同 `trendLast30Days[]`，无 `date`）

**`yesterday` — 昨日数据**（含以下额外增量字段）：

| 字段 | 类型 | 说明 |
|------|------|------|
| `uploadCountIncre` | number | 发布量较前日增量 |
| `playCountIncre` | number | 播放量较前日增量 |
| `playDuraCountIncre` | number | 播放时长较前日增量（秒） |
| `repostCountIncre` | number | 转发量较前日增量 |
| `commentCountIncre` | number | 评论量较前日增量 |
| `likeCountIncre` | number | 点赞量较前日增量 |

---

### 11. 粉丝画像数据

#### `data.fanPortrait` — 粉丝画像（截止昨日 T-1 的当前值）

| 字段 | 类型 | 说明 |
|------|------|------|
| `gender` | object | 粉丝性别分布：key 为 "男性"/"女性"，value 为百分比字符串 |
| `age` | object | 粉丝年龄分布：key 为 "小于18"/"18-24"/"25-34"/"35-44"/"大于44"，value 为百分比字符串 |
| `province` | object | 粉丝地区分布 TOP10：key 为省份名，value 为百分比字符串 |
| `tags` | object | 粉丝兴趣分布：key 为兴趣标签，value 为百分比字符串 |
| `fansPotential` | string | 昨日潜在粉丝量 |
| `fansPotentialIncre` | number | 潜在粉丝较前日增量（可为负数） |
| `fansTrans` | string | 昨日粉丝转化量 |
| `fansTransIncre` | number | 粉丝转化较前日增量（可为负数） |
| `bigvList` | array | 昨日新增大V关注列表（最多100个，见下表） |

**`bigvList[]` — 大V用户信息**：

| 字段 | 类型 | 说明 |
|------|------|------|
| `uid` | string | 大V用户ID |
| `screenName` | string | 大V昵称 |
| `followersCountStr` | string | 大V粉丝数（格式化字符串，如 "123.4万"） |
| `relation` | number | 关注关系：0=互未关注 / 1=对方关注我 / 2=我关注对方 / 3=互关 |

---

## 使用示例

```bash
# 获取创作者数据摘要
node scripts/weibo-creator.js summary --token=<your_token>

# 查看帮助
node scripts/weibo-creator.js help
```

返回示例：

```json
{
  "code": 0,
  "message": "success",
  "data": {
    "uid": 1234567890,
    "readTrend30Days": [
      { "date": "2026-05-07", "totalReadCount": 12500 },
      { "date": "2026-05-06", "totalReadCount": 9800 }
    ],
    "readSourceSummary30Days": {
      "followReadCount": 45000,
      "followReadRate": "55.8",
      "profileReadCount": 8000,
      "profileReadRate": "9.9",
      "searchReadCount": 15000,
      "searchReadRate": "18.6",
      "hotReadCount": 10000,
      "hotReadRate": "12.4",
      "othersReadCount": 2700,
      "othersReadRate": "3.3"
    },
    "postTrend30Days": [
      { "date": "2026-05-07", "statusCount": 3 }
    ],
    "interactTrend30Days": [
      { "date": "2026-05-07", "repostCount": 12, "commentCount": 45, "likeCount": 230 }
    ],
    "fanTrend7Days": [
      { "date": "2026-05-07", "fansTotal": 50000, "newFansCount": 120, "bigFanTotal": 3200, "newBigFanCount": 15 }
    ],
    "bigFanPortrait": {
      "pyramid": { "钻粉": "2.1", "金粉": "18.5", "铁粉": "79.4" },
      "gender": { "男性": "42.3", "女性": "57.7" },
      "age": { "小于18": "5.2", "18-24": "28.6", "25-34": "41.3", "35-44": "18.9", "大于44": "6.0" },
      "province": { "广东": "15.2", "北京": "12.8", "上海": "10.5", "浙江": "8.3", "江苏": "7.1" },
      "tags": { "科技": "32.1", "娱乐": "25.4", "体育": "18.7", "美食": "14.2", "旅行": "9.6" },
      "source": { "推荐流": "45.3", "搜索": "22.1", "关注流": "18.6", "个人主页": "9.4", "其他": "4.6" }
    },
    "topBlogs": [
      {
        "mid": "5127468523698745",
        "weiboText": "今天分享一个有趣的技术话题...",
        "createTimeText": "2026-05-06",
        "hasVid": 0,
        "readTotal": 85000,
        "readFans": 32000,
        "readNonfans": 53000,
        "repostTotal": 320,
        "commentTotal": 580,
        "likeTotal": 2100,
        "interactTotal": 3000
      }
    ],
    "rankDetails": [
      {
        "dt": "20260427",
        "fieldId": 10,
        "fieldName": "科技",
        "period": "2026年第18周",
        "scorePeriod": "04/27-05/03",
        "rank": "128",
        "totalScore": "76.5",
        "details": [
          { "name": "传播影响力得分", "score": "32.1", "fullScore": "40", "avgScore": "28.6" },
          { "name": "私域流量得分",   "score": "12.4", "fullScore": "",   "avgScore": "11.2" },
          { "name": "公域流量得分",   "score": "10.8", "fullScore": "",   "avgScore": "9.5"  },
          { "name": "内容效率得分",   "score": "8.9",  "fullScore": "",   "avgScore": "7.9"  },
          { "name": "内容吸引力得分", "score": "28.4", "fullScore": "35", "avgScore": "24.1" },
          { "name": "被互动得分",     "score": "16.2", "fullScore": "",   "avgScore": "13.8" },
          { "name": "粉丝吸引力得分", "score": "12.2", "fullScore": "",   "avgScore": "10.3" },
          { "name": "主动活跃度得分", "score": "16.0", "fullScore": "25", "avgScore": "14.5" },
          { "name": "主动活跃得分",   "score": "16.0", "fullScore": "",   "avgScore": "14.5" }
        ]
      }
    ]
  }
}
```

---

## 注意事项

1. 需要有效的 `token`，可通过 `weibo_token` 工具获取
2. 阅读数据为"排水阅读"（去除刷量等异常流量后的真实阅读数）
3. `fansTotal` 字段仅昨日（T-1）有值，其余日期可能为 `null`
4. 铁粉画像数据为截止昨日的当前值，非趋势数据
5. `topBlogs` 最多返回5条近期热门博文
6. `rankDetails` 返回最近4次周榜数据；若用户尚未上榜或数据不足，可能少于4条
7. `details` 中 `fullScore` 和 `avgScore` 为空字符串时表示该项无满分/均值数据
8. `groupSummary` 和 `groupDetails` 仅在用户开通粉丝群功能后有数据；未开通时可能为 `null`
9. `videoSummary` 仅在用户有视频发布记录时有数据；无视频时可能为 `null`
10. `fanPortrait` 为截止昨日的当前值，非趋势数据；`bigvList` 最多返回100个大V

---

## 数据分析能力

本技能在基础数据之上，提供以下加工数据和分析能力。当用户询问创作数据分析、金橙V升级、V榜排名、粉丝群运营等问题时，综合运用以下能力输出分析报告。

---

### 一、加工数据

以下数据由基础数据计算得出，可在分析报告中直接使用：

#### 互动效率数据

| 加工数据 | 计算方式 | 数据来源 |
|----------|----------|----------|
| 日互动总数 | 当日转发数 + 评论数 + 点赞数 | `interactTrend30Days` 各日 |
| 日千阅互动数 | 日互动总数 ÷ 日总排水阅读数 × 1000 | `interactTrend30Days` + `readTrend30Days` |
| 单条博文互动总数 | 转发总数 + 评论总数 + 赞总数 | `topBlogs[].repostTotal` + `commentTotal` + `likeTotal` |
| 单条博文千阅互动数 | 单条博文互动总数 ÷ 单条博文阅读总数 × 1000 | `topBlogs[]` |

> **千阅互动数**（每千次阅读带来的互动数）是衡量内容质量的核心指标，数值越高说明内容越能引发读者互动。

#### 博文排行数据

从 `topBlogs` 中按不同维度排序，找出 TOP5 博文：

| 排行类型 | 排序依据 | 说明 |
|----------|----------|------|
| 高阅读量博文 | `readTotal` 降序 | 近期阅读量最高的博文 |
| 高互动量博文 | 单条博文互动总数降序 | 近期互动量最高的博文 |
| 高千阅互动博文 | 单条博文千阅互动数降序 | 近期内容质量最高的博文 |

#### 增长速率数据

| 加工数据 | 计算方式 | 数据来源 |
|----------|----------|----------|
| 近30天条均阅读量 | 近30天总阅读量 ÷ 近30天发博总数 | `readTrend30Days` + `postTrend30Days` |
| 日均新增铁粉数 | 近7天 `newBigFanCount` 求和 ÷ 7 | `fanTrend7Days` |
| 日均新增粉丝数 | 近7天 `newFansCount` 求和 ÷ 7 | `fanTrend7Days` |
| 近30天阅读量趋势 | 对比前15天与后15天均值，判断上升/下降/平稳 | `readTrend30Days` |

---

### 二、金橙V 升级分析

> 升级标准详见：[金橙V 升级标准](references/creator-v-upgrade.md)

若用户询问金V/橙V升级相关问题，请按以下步骤进行分析：

#### 升级标准速查

| 等级 | 条件 |
|------|------|
| **橙V** | 已认证黄V ＋ 铁粉数 ≥ 100 ＋ 近30天排水阅读量 ≥ 30 万 |
| **金V** | 已认证黄V ＋ 粉丝量 ≥ 1 万 ＋ 铁粉数 ≥ 1000 ＋ 近30天排水阅读量 ≥ 1000 万 |

#### 分析步骤

**第一步：判断当前状态**

- **已是黄V，尚未达到橙V**：铁粉数 < 100 或近30天排水阅读量 < 30 万
- **已是橙V，尚未达到金V**：粉丝量 < 1 万 或 铁粉数 < 1000 或 近30天排水阅读量 < 1000 万

**第二步：计算各项达标差距**

| 指标 | 数据来源 | 计算方式 |
|------|----------|----------|
| 近30天排水阅读量 | `readTrend30Days` 所有 `totalReadCount` 求和 | 目标值 − 当前值 |
| 铁粉数 | `fanTrend7Days` 最新一条的 `bigFanTotal` | 目标值 − 当前值 |
| 粉丝量 | `fanTrend7Days` 最新一条的 `fansTotal` | 目标值 − 当前值 |

**第三步：预估达标时间**

```
距离达标天数 = 差距值 ÷ 日均增长量
```

- 阅读量：差距 ÷ (条均阅读量 × 日均发博数)
- 铁粉数：差距 ÷ 日均新增铁粉数
- 粉丝量：差距 ÷ 日均新增粉丝数

> 若日均增长量为 0 或负数，则说明当前趋势下无法自然达标，需要提升内容质量或发博频率。

**第四步：输出分析报告**

报告包含：当前状态、各项达标情况（✅/❌ + 差距数值）、增长速率、预估达标时间、提升建议。

#### 示例输出

```
📊 金橙V 升级分析报告

当前状态：已认证黄V，尚未达到橙V

各项指标达标情况（橙V标准）：
  ✅ 已认证黄V
  ❌ 铁粉数：当前 68，目标 100，还差 32（日均新增 2.1，预计约 16 天达标）
  ❌ 近30天排水阅读量：当前 18.5 万，目标 30 万，还差 11.5 万
       近30天共发博 24 条，条均阅读量约 7708
       按当前条均阅读量，每天需发 2 条博文，约 8 天可达标

增长趋势：
  近30天阅读量：整体呈上升趋势（后15天均值高于前15天 23%）
  近7天铁粉增长：日均新增 2.1 铁粉

建议：
  - 保持每天 2 条以上的发博频率，重点提升单条阅读量
  - 多发互动性强的内容，加速铁粉积累
```

---

### 三、V榜数据分析

若用户询问 V榜排名、得分、与同领域博主对比等问题，请按以下步骤进行分析：

#### 分析步骤

**第一步：整理最近4周榜单数据**

从 `rankDetails` 中按 `dt` 升序排列（最旧 → 最新），对每周提取综合总分、排名、9项明细得分及均值。

**第二步：分析总分与排名趋势**

| 判断维度 | 方法 |
|----------|------|
| 总分趋势 | 对比首周与末周总分，判断上升/下降/平稳 |
| 排名趋势 | 对比首周与末周排名（数字越小越靠前），判断进步/退步/稳定 |
| 波动情况 | 观察中间两周是否有明显波动 |

**第三步：分析9项明细数据**

将用户得分（`score`）与同领域同层级均值（`avgScore`）对比：

> 若 `avgScore` 为空字符串、缺失或无法解析为有效数值，则**跳过横向对比**，仅分析该项近4周的变化趋势，并在报告中注明"同领域均值缺失，无法进行横向对比"。

差距计算公式（`avgScore` 为有效正数时）：

```
差距 = |用户得分 - avgScore| ÷ avgScore
```

- **领先**：用户得分 > `avgScore`，且差距 ≥ 10%
- **持平**：差距 < 10%
- **落后**：用户得分 < `avgScore`，且差距 ≥ 10%

同时对比最近4周该项得分变化趋势：
- **进步**：末周得分 > 首周得分
- **退步**：末周得分 < 首周得分
- **稳定**：末周得分 ≈ 首周得分（差距 < 5%）

**第四步：输出分析报告**

报告包含：总分与排名趋势、领先项（优势）、落后项（需加强）、进步项、退步项、提升建议。

#### 示例输出

```
📊 V榜数据分析报告（科技领域）

最近4周总分与排名：
  第15周（04/06-04/12）：总分 71.2，排名 #156
  第16周（04/13-04/19）：总分 73.8，排名 #142
  第17周（04/20-04/26）：总分 75.1，排名 #135
  第18周（04/27-05/03）：总分 76.5，排名 #128
  → 总分持续上升（+5.3分），排名稳步提升（进步28位）✅

各维度对比（第18周 vs 同领域均值）：
  传播影响力：32.1 vs 均值 28.6 → 领先 12.2% ✅（近4周持续进步）
  内容吸引力：28.4 vs 均值 24.1 → 领先 17.8% ✅（近4周稳定）
  主动活跃度：16.0 vs 均值 14.5 → 领先 10.3% ✅

  子维度详情：
  ├ 私域流量：12.4 vs 均值 11.2 → 领先 10.7% ✅
  ├ 公域流量：10.8 vs 均值 9.5  → 领先 13.7% ✅（近4周进步最大）
  ├ 内容效率：8.9  vs 均值 7.9  → 领先 12.7% ✅
  ├ 被互动：  16.2 vs 均值 13.8 → 领先 17.4% ✅
  ├ 粉丝吸引：12.2 vs 均值 10.3 → 领先 18.4% ✅
  └ 主动活跃：16.0 vs 均值 14.5 → 领先 10.3% ✅
总结：
  - 各维度全面领先同领域均值，整体表现优秀
  - 公域流量得分近4周进步最为显著，建议继续保持
  - 主动活跃度满分25分，当前得分16.0，仍有较大提升空间，建议增加发博频率
```

---

### 四、粉丝群数据分析

若用户询问粉丝群运营情况、群活跃度、铁粉在群率等问题，请按以下步骤进行分析：

#### 加工数据

| 加工数据 | 计算方式 | 数据来源 |
|----------|----------|----------|
| 粉丝群发言人数占比 | 发言人数 ÷ 群成员总数 × 100% | `groupSummary.speakCountTrend` + `groupSummary.memberTotalTrend` |

> **发言人数占比**越高，表明群越活跃，说明更多成员养成了在群内发言的习惯。

#### 分析步骤

**第一步：分析群成员总数趋势**

从 `groupSummary.memberTotalTrend` 中按 `date` 升序排列（最旧 → 最新），对比首日与末日数值：
- **增长**：末日 > 首日，说明群成员在扩大
- **下降**：末日 < 首日，说明群成员在流失（结合 `joinCountTrend` 和 `leaveCountTrend` 分析原因）
- **平稳**：差距 < 5%

**第二步：分析群活跃度趋势**

从 `groupSummary.speakCountTrend` 中分析发言人数近7日变化趋势，并计算每日**发言人数占比**（发言人数 ÷ 群成员总数）：
- 占比越高，群越活跃
- 结合 `openCountTrend`（打开人数）分析：打开人数高但发言人数低，说明用户有阅读习惯但互动意愿不足

**第三步：分析铁粉在群率**

从 `groupSummary.bigfanInRateTrend` 中分析铁粉在群率近7日变化趋势：
- **铁粉在群率**越高，说明通过粉丝群运营铁粉越有效
- 若铁粉在群率低，建议主动邀请铁粉加入粉丝群

**第四步：分析各群详情（如有多个群）**

从 `groupDetails` 中对比各群的 `bigfanRate`，以及 `speakCountTrend`、`memberCountTrend` 近7日趋势，找出最活跃的群和需要重点运营的群。

**第五步：输出分析报告**

报告包含：群成员总数趋势、群活跃度（发言人数及占比趋势）、铁粉在群率趋势、各群对比（如有多群）、运营建议。

#### 示例输出

```
📊 粉丝群数据分析报告

群成员总数趋势（近7日）：
  05/08: 1,250人 → 05/14: 1,312人（+62人，增长 5.0%）✅
  进群 85人，退群 23人，净增 62人

群活跃度（近7日）：
  发言人数：日均 42人，占比约 3.3%
  打开人数：日均 186人，占比约 14.7%
  → 打开率较高，但发言率偏低，建议增加互动话题引导发言

铁粉在群率（近7日）：
  05/08: 18.2% → 05/14: 21.5%（持续上升）✅
  → 铁粉在群率稳步提升，粉丝群运营效果良好

建议：
  - 定期在群内发起话题讨论，提升发言人数占比
  - 主动邀请铁粉加入粉丝群，进一步提升铁粉在群率
  - 关注退群原因，减少群成员流失
```
```
